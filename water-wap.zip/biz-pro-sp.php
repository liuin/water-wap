<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="yuer-bk">      
      <h3 class="title1 bdbottom">商品管理</h3>   

<div class="order-list-block list-block media-list media-list-1">
                                    <ul>
                                    
                                      <li>
                                      
                                      <a href="pro-item.php" class="item-link item-content">
                                          <div class="item-media"><img src="http://j2.s2.dpfile.com/pc/e11360e0ed635a7b01c0cc68befc69d0(335c221)/thumb.jpg" alt="1906四川" title="1906四川"></div>
                                          <div class="item-inner">
                                            <div class="item-title-row">
                                              <div class="item-title">鲜香麻辣</div>
                                              <div class="item-after">$15</div>
                                            </div>
                                            <div class="item-subtitle"><span class="star"><span style="width:50%;"></span></span></div>
                                            <div class="item-text">红漆的矮方桌、小凳子，一锅红汤，和一大把一大把的竹签构成了一道特别风景。来自成都传奇小吃的串串香，口味麻辣鲜香，一锅红油涮着各种美味，真让人馋涎欲滴</div>
                                          </div></a>

<div class="biz-list-item  ">
      <div class="biz-row biz-row-name">
        <p class="col1">套餐信息:<span class="sp1">砂锅粥砂锅粥砂锅粥砂锅粥锅粥</span></p> 
        
      </div>
      <div class="biz-row">
        <p class="col1">消费张数:<span class="sp1">10</span></p> 
        <p class="col1">团购券号: <span class="sp1">1000</span></p>
      </div>
      <div class="biz-row">
        <p class="col1">消费时间: <span class="sp1">2015-10-10</span></p>
      </div>

    </div>

                                          <div class="info">
                                            <div class="oreder-btn-gorund">
                                              <a href="#" class="button button-fill color-indigo button-raised">编辑</a>
                                              <a href="#" class="button button-fill color-red button-raised">删除</a>
                                            </div>
                                          </div>
                                          </li>

                                          <li><a href="pro-item.php" class="item-link item-content">
                                          <div class="item-media"><img src="http://j2.s2.dpfile.com/pc/e11360e0ed635a7b01c0cc68befc69d0(335c221)/thumb.jpg" alt="1906四川" title="1906四川"></div>
                                          <div class="item-inner">
                                            <div class="item-title-row">
                                              <div class="item-title">鲜香麻辣</div>
                                              <div class="item-after">$15</div>
                                            </div>
                                            <div class="item-subtitle"><span class="star"><span style="width:50%;"></span></span></div>
                                            <div class="item-text">红漆的矮方桌、小凳子，一锅红汤，和一大把一大把的竹签构成了一道特别风景。来自成都传奇小吃的串串香，口味麻辣鲜香，一锅红油涮着各种美味，真让人馋涎欲滴</div>
                                          </div></a>
                                          <div class="info">
                                            <h3 class="pl-info-title">评论内容:</h3>
                                            <p class="p1">感觉上没有太古汇附近那间好，价钱也比那间贵，烤羊排竟然烤焦了，环境也吵，一般般吧。</p>
                                            <div class="oreder-btn-gorund">
                                              <a href="#" class="button button-fill color-indigo button-raised">删除</a>
                                              <a href="#" class="button button-fill color-red button-raised">删除</a>
                                            </div>
                                          </div>
                                          </li>
                                          <li><a href="pro-item.php" class="item-link item-content">
                                          <div class="item-media"><img src="http://j2.s2.dpfile.com/pc/e11360e0ed635a7b01c0cc68befc69d0(335c221)/thumb.jpg" alt="1906四川" title="1906四川"></div>
                                          <div class="item-inner">
                                            <div class="item-title-row">
                                              <div class="item-title">鲜香麻辣</div>
                                              <div class="item-after">$15</div>
                                            </div>
                                            <div class="item-subtitle"><span class="star"><span style="width:50%;"></span></span></div>
                                            <div class="item-text">红漆的矮方桌、小凳子，一锅红汤，和一大把一大把的竹签构成了一道特别风景。来自成都传奇小吃的串串香，口味麻辣鲜香，一锅红油涮着各种美味，真让人馋涎欲滴</div>
                                          </div></a>
                                          <div class="info">
                                            <h3 class="pl-info-title">评论内容:</h3>
                                            <p class="p1">感觉上没有太古汇附近那间好，价钱也比那间贵，烤羊排竟然烤焦了，环境也吵，一般般吧。</p>
                                            <div class="oreder-btn-gorund">
                                              <a href="#" class="button button-fill color-indigo button-raised">删除</a>
                                            </div>
                                          </div>
                                          </li>
                                     
                                        
                                    </ul>
                                  </div>
    </div>
  </div>
</div>