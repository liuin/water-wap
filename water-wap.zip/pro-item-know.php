<div data-page="swiper-fade" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">买家须知</div>
    </div>
  </div>
  <div class="page-content">
<div class="purchase-notes tab-pane-buyknow"> 
              <dl> 
               <dt>
                有效期
               </dt> 
               <dd> 
                <p class="listitem">2013-11-22至2015-10-29</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                除外日期
               </dt> 
               <dd> 
                <p class="listitem">2015-05-10、2015-06-20至2015-06-21不可用</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                使用时间
               </dt> 
               <dd> 
                <p class="listitem">09:00-14:30</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                预约信息
               </dt> 
               <dd> 
                <p class="listitem">无需预约，如遇消费高峰时段您可能需要排队</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                堂食外带
               </dt> 
               <dd> 
                <p class="listitem">本单只适用于堂食，只适用于大厅使用，敬请谅解</p> 
                <p class="listitem">本单不提供外送外卖服务</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                规则提醒
               </dt> 
               <dd> 
                <p class="listitem">每张团购券建议4人使用</p> 
                <p class="listitem">如部分菜品因时令或其他不可抗因素导致无法提供，店内会用等价菜品替换，具体事宜请与店内协商</p> 
                <p class="listitem">不再与其他优惠同享</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                商家服务
               </dt> 
               <dd> 
                <p class="listitem">提供免费WiFi</p> 
                <p class="listitem">停车位信息详询商户</p> 
               </dd> 
              </dl> 
              <dl> 
               <dt>
                温馨提示
               </dt> 
               <dd> 
                <p class="listitem">如需团购券发票，请您在消费时向商户咨询</p> 
               </dd> 
              </dl>
              <dl>
               <dt>
                优惠规则
               </dt> 
               <dd>
                <p class="listitem">本单为特惠单，不支持使用现金券/抵用券支付</p> 
               </dd> 
              </dl> 
             </div>
  </div>
</div>
