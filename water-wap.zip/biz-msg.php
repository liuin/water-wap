<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="yuer-bk">      
      <h3 class="title1 bdbottom">消息中心</h3>   

      <div class="msg-pro list-block media-list media-list-1">
        <div class="biz-msg-item-xt biz-msg-item">
          <h3>系统消息：</h3>
          <div class="txt">
            您好：的范德萨发生反对第三方的是否是
          </div>
          <a href="#" class="close">X</a>  
        </div>
        <div class="biz-msg-item">
          <h3>客户消息：</h3>
          <div class="txt">
            您好：的范德萨发生反对第三方的是否是
          </div>
          <a href="#" class="close">X</a>  
        </div>
      </div>
    </div>
  </div>
</div>