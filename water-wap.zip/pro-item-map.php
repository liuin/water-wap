<div data-page="pro-map" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">商家地址</div>
    </div>
  </div>
  <div class="page-content">
      <div id="bd-map1"></div>                    

  </div>
</div>