<div data-page="set" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content myset-page-content">
    <div class="my-set-title content-block">
      <h3>验证管理</h3>
    </div>
    <div class="adress-bk pro-title list-block"><a href="biz-val-tgj.php" class="item-link lyout-1">
              <h3 class="title1">验证团购劵 </h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="biz-val-yxh.php" class="item-link lyout-1">
              <h3 class="title1">已消费团购劵 </h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="biz-val-cx.php" class="item-link lyout-1">
              <h3 class="title1">团购劵状态查询</h3>             
            </a></div>

    <div class="my-set-title content-block">
      <h3>评价管理</h3>
    </div>
    <div class="adress-bk pro-title list-block"><a href="biz-pj-xfz.php" class="item-link lyout-1">
              <h3 class="title1">消费者评价 </h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="biz-pj-md.php" class="item-link lyout-1">
              <h3 class="title1">门店评价详情 </h3>             
            </a></div>


    <div class="my-set-title content-block">
      <h3>商品管理</h3>
    </div>
    <div class="adress-bk pro-title list-block"><a href="biz-pro-sp.php" class="item-link lyout-1">
              <h3 class="title1">商品管理 </h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="biz-pro-xg.php" class="item-link lyout-1">
              <h3 class="title1">经营效果 </h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="biz-pro-add.php" class="item-link lyout-1">
              <h3 class="title1">添加商品 </h3>             
            </a></div>

    <div class="my-set-title content-block">
      <h3>其他管理</h3>
    </div>
    <div class="adress-bk pro-title list-block"><a href="biz-update.php" class="item-link lyout-1">
              <h3 class="title1">上传审核 </h3>             
            </a></div>

    <div class="adress-bk pro-title list-block"><a href="biz-msg.php" class="item-link lyout-1">
              <h3 class="title1">消息中心 </h3>             
            </a></div>

    <div class="adress-bk pro-title list-block"><a href="biz-tk.php" class="item-link lyout-1">
              <h3 class="title1">提款管理 </h3>             
            </a></div>


    <div class="adress-bk pro-title list-block"><a href="biz-subnb.php" class="item-link lyout-1">
              <h3 class="title1">子账号管理（包括权限分配） </h3>             
            </a></div>


  </div>
</div>