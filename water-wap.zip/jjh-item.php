<div data-page="jjp-item" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="index.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center-t1">集结号</div>
    </div>
  </div>
  <div class="page-content">
    <div class="proit-img">
      <a href="#" class="ks-pb-standalone"><img width="100%" src="http://t3.s1.dpfile.com/pc/mc/b8980143c4aa6a9af0ef7a02149d7c67(450c280)/thumb.jpg"></a>
      <span class="proit-link-img"><a class="item-link ks-pb-standalone" href="#">点击查看详细图片</a></span>
    </div>
    <div class="row pro-item-price lyout-2 bdbottom">
      <div class="left col-50">参与人数<span class="proit-price"><span class="sp1"></span>90</span>人</div>
      <div class="right col-50"><a href="pay.php" class="button button-fill button-raised color-orange">立刻报名 </a></div>
    </div>
    <div class="adress-bk bdbottom lyout-1 list-block">
      <h3 class="title1 bdbottom">活动详情</h3> 
      <div class="jjh-des">吃在峨眉 耍在峨眉 成都全搜索邀请您周末峨眉山自驾游，体验峨眉山清凉夏日之旅。自峨眉山脚至金顶不到50公里的盘山公路，沿途享受峨眉山绮丽，峻险的风光，感受成都周边最刺激，最安全的山...</div>
      <div class="jjh-time">活动结束：2014-08-03 , 17:00:00 </div>
      <div class="jjh-row-box row-box">
        <div class="col-80">               
          <a href="pro-item-map.php" class="item-link"><p class="p1">地址: 大学城外环西路374号大学城外环西路374号大学城外环西路374号</p>
            <div class="tag">
              <span class="distance">&gt;100km</span>
            </div></a>
        </div>
        <div class="col-20">
          <a href="tel:02031105622" class="external tel-ly"><i class="moblie"></i></a>
        </div>

      
      </div>
      
    </div>

    
  </div>
</div>