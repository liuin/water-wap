<div data-page="pro-item" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="index.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center-t1">支付成功</div>
    </div>
  </div>
  <div class="page-content pay-suc-content">

    <div class="pay-suc-row ui-row bdbottom">
      <h3 class=" fl">支付成功</h3>
    </div>  

    <div class="pay-success alert alert-success" role="alert">
      <p class="p2"><span class="glyphicon glyphicon-ok" aria-hidden="true"></span>支付成功,你的订单号为10002</p>
      <a href="#" class="alert-link">查看我的订单</a>
    </div>    
  </div>
</div>