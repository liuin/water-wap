<div data-page="swiper-fade" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">团购详情</div>
    </div>
  </div>
  <div class="page-content">
    <table width="100%" cellpadding="0" cellspacing="0" class="table table-striped">
                  <thead>
                  <tr>
                    <th width="50%">名称</th>
                    <th width="25%">数量</th>
                    <th width="25%">单价</th>
                  </tr>
                  </thead>
                  <tbody>
                    <tr><th colspan="3">22选8,不可重复选</th></tr>
                    <tr>
                            <td>金蒜蒸排骨</td>
                            <td class="tc">顶点</td>
                            <td class="tc">22元</td>
                    </tr>
                    <tr>
                            <td>淡水虾饺皇</td>
                            <td class="tc">精点</td>
                            <td class="tc">29元</td>
                    </tr>
                    <tr>
                            <td>名酱百搭蒸凤爪</td>
                            <td class="tc">顶点</td>
                            <td class="tc">22元</td>
                    </tr>
                    <tr>
                            <td>好味菜蒸大肠</td>
                            <td class="tc">顶点</td>
                            <td class="tc">22元</td>
                    </tr>
                    <tr>
                            <td>古绵马拉糕</td>
                            <td class="tc">大点</td>
                            <td class="tc">15元</td>
                    </tr>
                    <tr>
                            <td>肉碎陈村粉</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>潮州蒸粉果</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>山东源汁枣皇糕</td>
                            <td class="tc">顶点</td>
                            <td class="tc">22元</td>
                    </tr>
                    <tr>
                            <td>阳江猪肠碌</td>
                            <td class="tc">小点</td>
                            <td class="tc">8元</td>
                    </tr>
                    <tr>
                            <td>金丝燕麦包</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>日式手指春卷</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>香菇滑肉肠</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>空心煎堆仔</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>腊味萝卜糕</td>
                            <td class="tc">大点</td>
                            <td class="tc">15元</td>
                    </tr>
                    <tr>
                            <td>虫草花鲜竹卷</td>
                            <td class="tc">大点</td>
                            <td class="tc">15元</td>
                    </tr>
                    <tr>
                            <td>香煎韭菜饺</td>
                            <td class="tc">顶点</td>
                            <td class="tc">22元</td>
                    </tr>
                    <tr>
                            <td>酥皮蛋挞仔</td>
                            <td class="tc">顶点</td>
                            <td class="tc">22元</td>
                    </tr>
                    <tr>
                            <td>特色荞麦包</td>
                            <td class="tc">大点</td>
                            <td class="tc">15元</td>
                    </tr>
                    <tr>
                            <td>汤灼娃娃菜</td>
                            <td class="tc">精点</td>
                            <td class="tc">29元</td>
                    </tr>
                    <tr>
                            <td>皮蛋瘦肉粥</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>泰国燕麦切糕</td>
                            <td class="tc">大点</td>
                            <td class="tc">15元</td>
                    </tr>
                    <tr>
                            <td>木瓜夹心椰汁糕</td>
                            <td class="tc">特点</td>
                            <td class="tc">19元</td>
                    </tr>
                    <tr>
                            <td>茶位费</td>
                            <td class="tc">4位</td>
                            <td class="tc">20元</td>
                    </tr>
                  <tr class="total">
                    <td colspan="2" class="total-col-1 tc">最高价值<br><strong>团购价</strong></td>
                    <td class="tc">210元<br><strong>98元</strong></td>
                  </tr>
                  </tbody>
                </table>
  </div>
</div>
