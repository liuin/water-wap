<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="yuer-bk">      
      <h3 class="title1 bdbottom">上传审核</h3>   

      <div class="add-pro list-block media-list media-list-1">
        <form action="#" class="add-form">
          <div class="form-ground">
            <div class="item-inner"> 
              <div class="item-title label">上传审核</div>
              <div class="item-input item-input-field">
                <input type="text" class="yh" placeholder="上传审核" class="">
              </div>
            </div>
          </div>
          <div class="form-sub">
            <a href="#" class="button button-fill button-raised">保　　存</a>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>