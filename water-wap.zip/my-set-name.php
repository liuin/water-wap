<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="set-email-llist-block list-block accordion-list">
      <ul>
        <li class="accordion-item accordion-item-expanded"><a href="#" class="item-link item-content">
            <div class="item-inner"> 
              <div class="item-title">基本信息</div>
            </div></a>
          <div class="accordion-item-content" style="height: auto;">
            <div class="content-block">
            
            
          <div class="list-block-set list-block inputs-list">
          <ul>
            <li>
              <div class="item-content">
            <div class="item-media"><i class="icon icon-form-name"></i></div>
            <div class="item-inner"> 
              <div class="item-title label">Name</div>
              <div class="item-input item-input-field">
                <input type="text" placeholder="Your name">
              </div>
            </div>
          </div>
            </li>
        <li>
          <div class="item-content">
            <div class="item-media"><i class="icon icon-form-gender"></i></div>
            <div class="item-inner not-empty-state"> 
              <div class="item-input item-input-field not-empty-state">
                <select class="not-empty-state">
                  <option>男</option>
                  <option>女</option>
                </select>
              </div>
            </div>
          </div>
        </li>
        <li>
          <div class="item-content">
            <div class="item-inner"> 
              <div class="item-input item-input-field">
                <input type="text" placeholder="常居地" class="">
              </div>
            </div>
          </div>
        </li>
        <li>
          <div class="item-content">
            <div class="item-inner"> 
              <div class="item-input item-input-field">
                 <textarea name="" placeholder="简单介绍下自己，让更多Dper了解你吧~~"></textarea>
              </div>
            </div>
          </div>
        </li>

            </ul>
            <a href="#" class="val-email-btn button button-fill button-raised">保存</a>
            </div>

              
            
            </div>
          </div>
        </li>
        
        
      </ul>
    </div>
  </div>
</div>