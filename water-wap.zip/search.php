
<div data-page="searchbar" class="page">  
  
  <form  class="searchbar">
    <a href="#" class="back link icon-only"><i class="icon icon-back"></i></a>
    <div class="searchbar-input">
      <input type="search" placeholder="Search"/><a href="#" id="searchbar-config" class="button searchbar-config button-raised button-fill color-indigo">确定</a>
    </div>
  </form>
  <div class="searchbar-overlay"></div>
  <div class="page-content">
    <div class="list-block searchbar-not-found">
      <ul>
        <li class="item-content">
          <div class="item-inner">
            <div class="item-title"></div>
          </div>
        </li>
      </ul>
    </div>
    <div class="list-block search-here searchbar-found">
       
     <ul> <li>
          <a href="search-page.php?value=自助餐" class="button item-title color-orange ">自助餐</a>
        </li>
        <li>
          <a href="search-page.php?value=粤菜" class="button item-title  color-pink ">粤菜</a>
        </li>
        <li>
          <a href="search-page.php?value=面包甜点面包甜点" class="button item-title  color-purple ">面包甜点面包甜点</a>
        </li>
        <li>
          <a href="search-page.php?value=自助餐" class="button item-title color-orange ">自助餐</a>
        </li>
        <li>
          <a href="search-page.php?value=粤菜" class="button item-title  color-pink ">粤菜</a>
        </li>
        <li>
          <a href="search-page.php?value=面包甜点" class="button item-title  color-purple ">面包甜点</a>
        </li>
        <li>
          <a href="search-page.php?value=自助餐" class="button item-title color-orange ">自助餐</a>
        </li>
        <li>
          <a href="search-page.php?value=粤菜" class="button item-title  color-pink ">粤菜</a>
        </li>
        <li>
          <a href="search-page.php?value=面包甜点" class="button item-title  color-purple ">面包甜点</a>
        </li>   </ul>
    </div>
  </div>
</div>