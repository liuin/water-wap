<div data-page="biz-subnb" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content">
    <div class="yuer-bk">      
      <h3 class="title1 bdbottom">子账号管理(包括权限分配)</h3>             
      <div class="biz-subnb">
        <table class="tabel table-striped">
          <tbody><tr> 
            <th>名字</th>
            <th>只读</th>
            <th>读写</th>
            <th>删除</th>
          </tr>
          <tr>
            <td>刘旭</td>
            <td class="label-ck">
            <label class="label-checkbox item-content">
              <input type="checkbox" name="ks-checkbox" value="Movies">
              <div class="item-media"><i class="icon icon-form-checkbox"></i></div>        
            </label>
          </td>
                      <td class="label-ck">
                      <label class="label-checkbox item-content">
                        <input type="checkbox" name="ks-checkbox" value="Movies">
                        <div class="item-media"><i class="icon icon-form-checkbox"></i></div>        
                      </label>
                    </td>
            <td><a href="#" class="button button-raised button-fill color-red">删　除</a></td>
          </tr>
          <tr>
            <td>刘旭</td>
                        <td class="label-ck">
                        <label class="label-checkbox item-content">
                          <input type="checkbox" name="ks-checkbox" value="Movies">
                          <div class="item-media"><i class="icon icon-form-checkbox"></i></div>        
                        </label>
                      </td>
                                  <td class="label-ck">
                                  <label class="label-checkbox item-content">
                                    <input type="checkbox" name="ks-checkbox" value="Movies">
                                    <div class="item-media"><i class="icon icon-form-checkbox"></i></div>        
                                  </label>
                                </td>
            <td><a href="#" class="button button-raised button-fill color-red">删　除</a></td>
          </tr>
          <tr>
            <td>刘旭</td>
                        <td class="label-ck">
                        <label class="label-checkbox item-content">
                          <input type="checkbox" name="ks-checkbox" value="Movies">
                          <div class="item-media"><i class="icon icon-form-checkbox"></i></div>        
                        </label>
                      </td>
                                  <td class="label-ck">
                                  <label class="label-checkbox item-content">
                                    <input type="checkbox" name="ks-checkbox" value="Movies">
                                    <div class="item-media"><i class="icon icon-form-checkbox"></i></div>        
                                  </label>
                                </td>
            <td><a href="#" class="button button-raised button-fill color-red">删　除</a></td>
          </tr>
        </tbody>
        </table>
      </div>
    </div>
  </div>
</div>