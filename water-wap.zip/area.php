<div data-page="area" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="index.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">地区</div>
<!--       <div class="right"><a href="#" class="open-panel link icon-only"><i class="icon icon-bars"></i></a></div> -->
    </div>
  </div>
  <div class="page-content contacts-content">
    <div class="list-block contacts-block">
      <div class="list-group">
        <ul>
          <li class="list-group-title">热门地区</li>
          <li>
            <a href="index.php?area=广州" class="item-link"><div class="item-content">
                <div class="item-inner">
                  <div class="item-title">广州</div>
                </div>
              </div></a>
          </li>
          <li>
            <a href="index.php?area=上海" class="item-link">
            <div class="item-content">
              
                <div class="item-inner">
                  <div class="item-title">上海</div>
                </div>
              
            </div></a>
          </li>
          <li>
            <a href="index.php?area=深圳" class="item-link">
            <div class="item-content">
              <div class="item-inner">
                  <div class="item-title">深圳</div>
                </div>
            </div></a>
          </li>
        </ul>
      </div>
      
  
      <div class="list-group">
        <ul>
          <li class="list-group-title">其他地区</li>
          <li>
            <a href="index.php?area=厦门" class="item-link"><div class="item-content">
                <div class="item-inner">
                  <div class="item-title">厦门</div>
                </div>
              </div></a>
          </li>
          <li>
            <a href="index.php?area=东莞" class="item-link"><div class="item-content">
                <div class="item-inner">
                  <div class="item-title">东莞</div>
                </div>
              </div></a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>