<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="yuer-bk">
      <h3 class="title1 bdbottom">已消费团购劵</h3>
      
      
    <div class="yuer-info-yxf yuer-info">
    <div class="biz-list-item bdbottom ">
      <div class="biz-row biz-row-name">
        <p class="col1">套餐信息:<span class="sp1">砂锅粥砂锅粥砂锅粥砂锅粥锅粥</span></p> 
        
      </div>
      <div class="biz-row">
        <p class="col1">消费张数:<span class="sp1">10</span></p> 
        <p class="col1">团购券号: <span class="sp1">1000</span></p>
      </div>
      <div class="biz-row">
        <p class="col1">消费时间: <span class="sp1">2015-10-10</span></p>
      </div>
      <div class="oreder-btn-gorund">
        <a href="#" class="button button-fill color-red button-raised">删除</a>
      </div>
    </div>

<div class="biz-list-item bdbottom ">
      <div class="biz-row biz-row-name">
        <p class="col1">套餐信息:<span class="sp1">砂锅粥砂锅粥砂锅粥砂锅粥锅粥</span></p> 
        
      </div>
      <div class="biz-row">
        <p class="col1">消费张数:<span class="sp1">10</span></p> 
        <p class="col1">团购券号: <span class="sp1">1000</span></p>
      </div>
      <div class="biz-row">
        <p class="col1">消费时间: <span class="sp1">2015-10-10</span></p>
      </div>
      <div class="oreder-btn-gorund">
        <a href="#" class="button button-fill color-red button-raised">删除</a>
      </div>
    </div>

<div class="biz-list-item bdbottom ">
      <div class="biz-row biz-row-name">
        <p class="col1">套餐信息:<span class="sp1">砂锅粥砂锅粥砂锅粥砂锅粥锅粥</span></p> 
        
      </div>
      <div class="biz-row">
        <p class="col1">消费张数:<span class="sp1">10</span></p> 
        <p class="col1">团购券号: <span class="sp1">1000</span></p>
      </div>
      <div class="biz-row">
        <p class="col1">消费时间: <span class="sp1">2015-10-10</span></p>
      </div>
      <div class="oreder-btn-gorund">
        <a href="#" class="button button-fill color-red button-raised">删除</a>
      </div>
    </div>
    

    <p class="valp1">验证时间超过10分钟的团购券如需退款，请引导会员联系点评客服400-820-5527处理</p>

  </div></div>
  </div>
</div>