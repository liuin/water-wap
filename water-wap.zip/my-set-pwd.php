<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="set-email-llist-block list-block accordion-list">
      <ul>
        <li class="accordion-item accordion-item-expanded"><a href="#" class="item-link item-content">
            <div class="item-inner"> 
              <div class="item-title">修改密码</div>
            </div></a>
          <div class="accordion-item-content" style="height: auto;">
            <div class="content-block">
            
            
          <div class="list-block-set list-block inputs-list">
          <ul>
            <li>
          <div class="item-content">
            <div class="item-media"><i class="icon icon-form-password"></i></div>
            <div class="item-inner"> 
              <div class="item-title label">原来密码</div>
              <div class="item-input item-input-field">
                <input type="password" placeholder="Password">
              </div>
            </div>
          </div>
        </li>
        <li>
          <div class="item-content">
            <div class="item-media"><i class="icon icon-form-password"></i></div>
            <div class="item-inner"> 
              <div class="item-title label">新密码</div>
              <div class="item-input item-input-field">
                <input type="password" placeholder="Password">
              </div>
            </div>
          </div>
        </li>
         <li>
          <div class="item-content">
            <div class="item-media"><i class="icon icon-form-password"></i></div>
            <div class="item-inner"> 
              <div class="item-title label">确认新密码</div>
              <div class="item-input item-input-field">
                <input type="password" placeholder="Password">
              </div>
            </div>
          </div>
        </li>
          

            </ul>
            <a href="#" class="val-email-btn button button-fill button-raised">保存</a>
            </div>

              
            
            </div>
          </div>
        </li>
        
        
      </ul>
    </div>
  </div>
</div>