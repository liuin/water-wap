<div data-page="swiper-fade" class="page">
  <div class="navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">会员评价</div>
    </div>
  </div>
  <div class="page-content">
    <div class="tab-pane cumpj-tab-pane active" id="cumpj">
            <div class="preson-order-item first bdbottom">
              <div class="user clearfix ">
                <div class="star-wp fl">
                  <span class="fl">评价:</span><div class="star fl"><span style="width:20%;" class="sp1"></span></div>                 
                </div>                  
                <div class="name fl">刘**</div>
                <div class="time fr"><span class="sp1">购买时间:</span>2015-07-26</div>
              </div>
              <div class="txt1">内容:感觉上没有太古汇附近那间好，价钱也比那间贵，烤羊排竟然烤焦了，环境也吵，一般般吧。</div>
            </div>
            <div class="preson-order-item bdbottom">
              <div class="user clearfix">
                <div class="star-wp fl">
                  <span class="fl">评价:</span><div class="star fl"><span style="width:20%;" class="sp1"></span></div>                 
                </div>                  
                <div class="name fl">刘**</div>
                <div class="time fr"><span class="sp1">购买时间:</span>2015-07-26</div>
              </div>
              <div class="txt1">内容:感觉上没有太古汇附近那间好，价钱也比那间贵，烤羊排竟然烤焦了，环境也吵，一般般吧。</div>
            </div>
            <div class="preson-order-item ">
              <div class="user clearfix">
                <div class="star-wp fl">
                  <span class="fl">评价:</span><div class="star fl"><span style="width:20%;" class="sp1"></span></div>                 
                </div>                  
                <div class="name fl">刘**</div>
                <div class="time fr"><span class="sp1">购买时间:</span>2015-07-26</div>
              </div>
              <div class="txt1">内容:感觉上没有太古汇附近那间好，价钱也比那间贵，烤羊排竟然烤焦了，环境也吵，一般般吧。</div>
            </div>                        
            </div>
  </div>
</div>
