<div data-page="tabs" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content my-page-content">
    <div class="yuer-bk">      
      <h3 class="title1 bdbottom">提款管理</h3>   

      <div class="order-xg">
        欠数据        
      </div>
    </div>
  </div>
</div>