<div data-page="set" class="page">
  <div class="navbar my-navbar">
    <div class="navbar-inner">
      <div class="left"><a href="swiper.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center">我的</div>
      <div class="top-search">刘旭(广州黄埔)</div>
      <div class="right"><a href="my-set.php" class="item-link">退出</a></div>
    </div>
  </div>
  <div class="page-content myset-page-content">
    <div class="my-set-title content-block">
      <h3>我的设置</h3>
    </div>
    <div class="adress-bk pro-title list-block"><a href="my-set-email.php" class="item-link lyout-1">
              <h3 class="title1">邮箱设置 <span class="sp1">d****1@dpmobile.com (未验证)</span> </h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="my-set-name.php" class="item-link lyout-1">
              <h3 class="title1">修改用户名 <span class="sp1">QQ_7404829030</span></h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="my-set-pwd.php" class="item-link lyout-1">
              <h3 class="title1">登录密码</h3>             
            </a></div>
    <div class="adress-bk pro-title list-block"><a href="my-set-tel.php" class="item-link lyout-1">
              <h3 class="title1">手机绑定</h3>             
            </a></div>
  </div>
</div>